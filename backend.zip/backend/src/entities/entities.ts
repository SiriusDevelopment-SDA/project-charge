
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity()
export class Clients {
  @Column({ unique: true })
  cnpj_cpf: string;

  @Column()
  name: string;

  @Column()
  street: string;

  @Column()
  city: string;

  @Column({ length: 9 })
  zipCode: string;

  @Column()
  company: string;

  @Column()
  clientId: string;

  @Column()
  remoteJid: string;

  @Column()
  whatsapp: string;

  @Column()
  email: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

//   @OneToOne(() => User, (user) => user.address, { nullable: false })
//   @JoinColumn()
//   user: User;
}