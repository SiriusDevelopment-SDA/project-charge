import { Injectable } from '@nestjs/common';

@Injectable()
export class AppServiceIxc {
  getClients(): string {
    return 'Hello World! aquii é ixc estou aqui';
  }
}
