import { AppServiceIxc } from './app.services';
import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  UseGuards,
} from '@nestjs/common';

@Controller()
export class AppIxc {
  constructor(private readonly appService: AppServiceIxc) {}

  @Get('ixc')
  getClients(@Body() client: ClientDto ): string {
    return this.appService.getClients();
  }
}
