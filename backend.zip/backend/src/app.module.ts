import { Module } from '@nestjs/common';
import { AppIxc } from './app.controllers';
import { AppServiceIxc } from './app.services';

@Module({
  imports: [],
  controllers: [AppIxc],
  providers: [AppServiceIxc],
})
export class AppModule {}
